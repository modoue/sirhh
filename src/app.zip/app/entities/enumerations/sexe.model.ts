export enum SEXE {
  HOMME = 'HOMME',

  FEMME = 'FEMME',
}
