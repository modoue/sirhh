export const locale = {
    lang: 'tr',
    data: {
        'SAMPLE': {
            'HELLO': 'Merhaba Dünya!'
        }
    }
};
